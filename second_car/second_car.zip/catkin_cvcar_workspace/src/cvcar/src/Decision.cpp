#include "ros/ros.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Bool.h"
#include "std_msgs/Int32.h"
#include <iostream>
#include <string>


int L_Loc;
int R_Loc;
int C_Loc;


int Servo_Value;

//int Car_Dist;
bool Traf_Light;
bool Traf_Signal;
bool Sonar;
bool Stop_Check;

double Kp = 0.55;
double Ki = 0.0005;
double Kd = 0.30;

double error;
double error_prev;
double i_error;

int desired_value=320;
int current_value;

double P_control=0, I_control=0, D_control=0;
double Time = 0.1;
double PID_control;

int filter_num=0;
double err_arr[8];
bool isFirst=true;
int change_num=0;
double max_e=-9999;
double min_e=9999;
double sum_err_arr=0;
double filtered_error;



double filtered_value=0;



void int_cb1(const std_msgs::Int32::ConstPtr& msg)
{
	L_Loc=msg->data;
}
void int_cb2(const std_msgs::Int32::ConstPtr& msg)
{
	R_Loc=msg->data;
}
void int_cb3(const std_msgs::Int32::ConstPtr& msg)
{
	C_Loc=msg->data;
}

void bool_cb1(const std_msgs::Bool::ConstPtr& msg) //traffic light
{
	Traf_Light = msg->data;
}
void bool_cb2(const std_msgs::Bool::ConstPtr& msg) //traffic signal
{
	Traf_Signal = msg->data;
}
void bool_cb3(const std_msgs::Bool::ConstPtr& msg) //sonar
{
	Sonar = msg->data;
}


int main(int argc, char **argv)
{
	
	ros::init(argc, argv, "Decision");
	ros::NodeHandle n;

	int i=0;
	bool check_stop=false;
	bool check_sl=false;

	ros::Subscriber left_location = n.subscribe("l_location", 30, int_cb1);	

	ros::Subscriber right_location = n.subscribe("r_location", 30, int_cb2);

	ros::Subscriber center_location = n.subscribe("c_location", 30, int_cb3);	
/*
	ros::Subscriber traffic_light = n.subscribe("traf", 30, bool_cb1);
		
	ros::Subscriber traffic_signal = n.subscribe("sign", 30, bool_cb2);

	ros::Subscriber front_sonar = n.subscribe("sonar", 30, bool_cb3);
*/
	ros::Publisher servo_pub=n.advertise<std_msgs::Int32>("servo",30);

	//ros::Publisher isstop_pub= n.advertise<std_msgs::Bool>("stop", 30);

	ros::Rate loop_rate(30);

	while(ros::ok())
	{
		std_msgs::Int32 servo;
		std_msgs::Bool isstop;


		//pid control
		current_value=C_Loc;
		error= current_value-desired_value;

		if(filter_num<8)
		{
			if(isFirst == true)
			{
				err_arr[filter_num]=error;
				filter_num++;
			}
			else
			{
				err_arr[change_num]=error;
				filter_num++;
				change_num++;
			}
		}
		else if(filter_num==8)
		{
			for(int k=0; k<filter_num; k++)
			{
				if(max_e < err_arr[i])
					max_e=err_arr[i];
				if(min_e > err_arr[i])
					min_e=err_arr[i];
				sum_err_arr+=err_arr[i];
			}
			filtered_error=(sum_err_arr - max_e - min_e)/(filter_num-2);
			sum_err_arr=0;
			max_e = -9999;
			min_e = 9999;

			isFirst=false;
			filter_num--;
			if(change_num==8);
				change_num=0;
		}

		P_control = Kp * filtered_error;
		i_error += filtered_error*Time;
		I_control = Ki * i_error;
		D_control = Kd * (filtered_error-error_prev)/Time;


		error_prev = filtered_error;

		PID_control = P_control + I_control + D_control;

		Servo_Value = (int)PID_control;

		//check stop situation
		/*
		bool tl = Traf_Light;
		bool ts = Traf_Signal;
		bool fs = Sonar;

		if (tl == true && ts == false && fs == false)
			Stop_Check = false;	//go
		else
			Stop_Check = true;	//stop

		isstop.data = Stop_Check;
		*/
		servo.data=Servo_Value;

		//isstop_pub.publish(isstop);

		servo_pub.publish(servo);

		//std::printf("stop : %d\n", Stop_Check);
		std::printf("servo_value : %d\n",Servo_Value);
		ros::spinOnce();
		loop_rate.sleep();
	}
	ros::spin();



	return 0;
}
