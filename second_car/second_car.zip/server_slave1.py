import socket
import sys

import rospy
#from std_msgs.msg import String
from std_msgs.msg import Bool

HOST = '' #all available interfaces
PORT = 8808

pub_slv = rospy.Publisher('car_slave', Bool, queue_size=10)


rospy.init_node('server_truck')

str_val=''
i = 0

# 1. open Socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Socket created')

# 2. bind to a address and port
try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print('Bind Failed. Error code: ' + str(msg[0]) + ' Message: ' + msg[1])
    sys.exit()

print('Socket bind complete')

# 3. Listen for incoming connections
s.listen(10)
print('Socket now listening')

# 4. Accept connection
conn, addr = s.accept()
print('Connected with ' + addr[0] + ':' + str(addr[1]))
# keep talking with the client
while 1:

    # 5. Read/Send
    data = conn.recv(1024)
    if not data:
        break
    conn.sendall(data)
    #print(data)

    val = data.split(':')
    if(val[0] == 'slv'):
        print("slv is "+ val[1])
        if(val[1]=='True'):
            slv_data=True
            pub_slv.publish(slv_data)
        elif(val[1]=='False'):
            slv_data = False
            pub_slv.publish(slv_data)



conn.close()
s.close()
