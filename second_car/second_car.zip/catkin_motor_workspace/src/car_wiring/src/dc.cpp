#include <stdio.h>
#include "softPwm.h"
#include "wiringPi.h"
#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Bool.h"

bool stop;
int c_dist;

float mul=1.0;

int pid_val;
int speed;
/*
void tl_CB(const std_msgs::Bool::ConstPtr& msg)
{
	tl=msg->data;
}
void stop_CB(const std_msgs::Bool::ConstPtr& msg)
{
	stop_sign=msg->data;
}
void front_CB(const std_msgs::Bool::ConstPtr& msg)
{
	front_obst=msg->data;
}
*/
void c_dist_CB(const std_msgs::Int32::ConstPtr& msg)
{
	c_dist = msg->data;
}
void stop_CB(const std_msgs::Bool::ConstPtr& msg)
{
	stop = msg->data;
}

void PID_CB(const std_msgs::Int32::ConstPtr& msg)
{
	pid_val=msg->data;
}

int main(int argc, char **argv)
{
	const int INA=24;
	const int IN1=27;
	const int IN2=23;

	//traffic_light

	
	wiringPiSetup();

	ros::init(argc,argv, "dc_node");
	ros::NodeHandle sn;
	

	pinMode(INA, PWM_OUTPUT);
	pinMode(IN1, OUTPUT);
	pinMode(IN2, OUTPUT);

	ros::Rate rate(30);
	//ros::Subscriber val=sn.subscribe("traffic_light",10,tl_CB);
	ros::Subscriber pid=sn.subscribe("servo",30,PID_CB);
	ros::Subscriber car_distance = sn.subscribe("c_dist", 30, c_dist_CB);
	ros::Subscriber isstop = sn.subscribe("car_slave",30,stop_CB);
	//ros::Subscriber front_obstacle=sn.subscribe("sonar",10,front_CB);


	while(ros::ok())
	{
		/*if(pid_val >=0)
			speed=400-pid_val;
			//speed=400;
		else if(pid_val<0)
			speed=400+pid_val;
			//speed=400;

		if(speed < 400)
			speed=400;
		else if(speed > 500)
			speed=500;*/
	

		if (c_dist < 30)
			mul = 0.9;
		else if (c_dist >= 30 && c_dist < 40)
			mul = 1.0;
		else if (c_dist >= 40)
			mul = 1.2;
		
		if(pid_val >=30 || pid_val <= -30)	//previous value : 400
			speed=430;
		else if((pid_val > -30 && pid_val <=-20)||(pid_val < 30 && pid_val >= 20))
			speed=430;
		else if((pid_val > -20 && pid_val <=-10)||(pid_val < 20 && pid_val >= 10))
			speed=430;
		else 
			speed=430 * mul;

	


		/*tl=true; //after test, erase this line
		if(tl == true && stop_sign == false && front_obst == false)
		{
			printf("go! speed:%d\n",speed);
			digitalWrite(IN1, HIGH);
			digitalWrite(IN2, LOW);
			pwmWrite(INA, speed);
		}
		else if(tl == false || stop_sign == true || front_obst == true)
		{
			std::cout << tl << stop_sign << front_obst << std::endl;
			printf(" stop!\n");
			
			digitalWrite(IN1, LOW);
			digitalWrite(IN2, LOW);
			pwmWrite(INA, 0);
		}*/
		if (stop == true)//stop
		{
			digitalWrite(IN1, LOW);
			digitalWrite(IN2, LOW);
			pwmWrite(INA, 0);
		}
		else if (stop == false)//go
		{
			digitalWrite(IN1, HIGH);
			digitalWrite(IN2, LOW);
			pwmWrite(INA, speed);
		}


		ros::spinOnce();
		rate.sleep();
	}

	return 0;

}
