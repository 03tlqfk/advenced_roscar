#include <unistd.h>
#include <stdio.h>
#include "wiringPi.h"
#include <ros/ros.h>
#include <std_msgs/Int32.h>

//gcc -o sensor sensor.cpp -lwiringPi -lpthread

#define MAX_COUNT 10000

const int trig = 5;
const int echo = 4;
//int dist_value=0;

int main (int argc, char** argv) 
{	
	ros::init(argc, argv, "Sonar");	
	ros::NodeHandle s;	
	ros::Publisher front_dist=s.advertise<std_msgs::Int32>("front_dist",10);
	int dis;
	long startTime;
	long travelTime;
	long startSensor;
	long endSensor;
	int count;

	ros::Rate loop_rate(30);
	wiringPiSetup();
	pinMode(trig, OUTPUT);
	pinMode(echo, INPUT);

	while(ros::ok()) 
	{
		startSensor = micros();
		count = 0;
		digitalWrite(trig, LOW);
		usleep(2);
		digitalWrite(trig, HIGH);
		usleep(20);
		digitalWrite(trig, LOW);
		while(digitalRead(echo) == LOW) 
		{			
			if (count >= MAX_COUNT)
				break;
				count++;	
		}
		startTime = micros();
		while(digitalRead(echo) == HIGH) 
		{
			if (count >= MAX_COUNT)		
				break;
				count++;
		}
		travelTime = micros() - startTime;	
		if (count < MAX_COUNT)	
			dis = travelTime / 58;
		else
			dis = 1000;	
		std_msgs::Int32 f_dist;
		f_dist.data=dis;
		front_dist.publish(f_dist);
		/*if(dis < 10)
			printf("dis : %d stop!!!!!!!!!!!!!!!!!!!!!!!!!\n", dis);
		else
			printf("dis : %d\n", dis);*/

		endSensor = micros();
		usleep(30000 - endSensor + startSensor);
		//delay(200);
		ros::spinOnce();
		loop_rate.sleep();

	}
	ros::spin();
	return 0;
}
