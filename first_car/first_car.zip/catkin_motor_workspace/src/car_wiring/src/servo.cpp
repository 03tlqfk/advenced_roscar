#include <stdio.h>
#include "softPwm.h"
#include "wiringPi.h"
#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include <softServo.h>

int pid_val;

void PID_CB(const std_msgs::Int32::ConstPtr& msg)
{
	pid_val=msg->data;
}

int main(int argc, char **argv)
{
	const int servo_pin=1;
	
	char input;
	int angle;
	
	wiringPiSetup();

	pinMode(servo_pin, PWM_OUTPUT);

	softPwmCreate(servo_pin,0,300);

	ros::init(argc,argv, "servo_node");
	ros::NodeHandle sn;
	ros::Rate rate(30);

	ros::Subscriber val=sn.subscribe("servo",30,PID_CB);
	softServoSetup (1, -1, -1, -1, -1, -1, -1, -1) ;
	//digitalWrite(IN1, HIGH);
	//digitalWrite(IN2, LOW);

	while(ros::ok())
	{
		angle=400+(pid_val*3.5); //previous factor : 3.4, 780, 180
		if(angle > 700)
			angle = 700;
		else if(angle < 100)
			angle = 100;
		softServoWrite (1,  angle) ;

		ros::spinOnce();
		rate.sleep();
	}



	return 0;
}
