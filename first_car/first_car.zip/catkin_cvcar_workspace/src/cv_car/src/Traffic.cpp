#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <stdlib.h>
#include <time.h>
#include <std_msgs/Bool.h>

#define PI 3.1415926

static const std::string OPENCV_WINDOW = "Lane Image window";

int threshold1 = 70;

cv::Vec3b lower_red1, upper_red1, lower_red2, upper_red2, lower_red3, upper_red3;
cv::Vec3b lower_yellow1, upper_yellow1, lower_yellow2, upper_yellow2, lower_yellow3, upper_yellow3;
cv::Vec3b lower_green1, upper_green1, lower_green2, upper_green2, lower_green3, upper_green3;
cv::Mat img_color;
bool isred=false, isyellow=false, isgreen=false;
int hue_r_GB=3, hue_y_GB=30, hue_g_GB=73;
void check_traffic_light(int r, int y, int g)
{
	int hue_r = r;
	int hue_y = y;
	int hue_g = g;

	lower_red1 = cv::Vec3b(hue_r - 10 + 180, threshold1, threshold1);
	upper_red1 = cv::Vec3b(180, 255, 255);
	lower_red2 = cv::Vec3b(0, threshold1, threshold1);
	upper_red2 = cv::Vec3b(hue_r, 255, 255);
	lower_red3 = cv::Vec3b(hue_r, threshold1, threshold1);
	upper_red3 = cv::Vec3b(hue_r + 10, 255, 255);

	lower_yellow1 = cv::Vec3b(hue_y, threshold1, threshold1);
	upper_yellow1 = cv::Vec3b(hue_y + 10, 255, 255);
	lower_yellow2 = cv::Vec3b(hue_y - 10, threshold1, threshold1);
	upper_yellow2 = cv::Vec3b(hue_y, 255, 255);
	lower_yellow3 = cv::Vec3b(hue_y - 10, threshold1, threshold1);
	upper_yellow3 = cv::Vec3b(hue_y, 255, 255);

	lower_green1 = cv::Vec3b(hue_g, threshold1, threshold1);
	upper_green1 = cv::Vec3b(hue_g + 10, 255, 255);
	lower_green2 = cv::Vec3b(hue_g - 10, threshold1, threshold1);
	upper_green2 = cv::Vec3b(hue_g, 255, 255);
	lower_green3 = cv::Vec3b(hue_g - 10, threshold1, threshold1);
	upper_green3 = cv::Vec3b(hue_g, 255, 255);
}

cv::Mat morphologyColor(int hue_value, cv::Mat img_hsv, cv::Mat img_color, cv::Vec3b lower_color1, cv::Vec3b lower_color2, cv::Vec3b lower_color3, cv::Vec3b upper_color1, cv::Vec3b upper_color2, cv::Vec3b upper_color3, std::vector<cv::Vec3f>circle)
{
	cv::Mat img_mask1, img_mask2, img_mask3, img_mask;
	inRange(img_hsv, lower_color1, upper_color1, img_mask1);
	inRange(img_hsv, lower_color2, upper_color2, img_mask2);
	inRange(img_hsv, lower_color3, upper_color3, img_mask3);
	img_mask = img_mask1 | img_mask2 | img_mask3;

	int morph_size = 2;
	cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(2 * morph_size + 1, 2 * morph_size + 1),
		cv::Point(morph_size, morph_size));
	morphologyEx(img_mask, img_mask, cv::MORPH_OPEN, element);
	morphologyEx(img_mask, img_mask, cv::MORPH_CLOSE, element);

	cv::Mat img_result;
	bitwise_and(img_color, img_color, img_result, img_mask);

	cv::Mat img_labels, stats, centroids;
	int numOfLabels = connectedComponentsWithStats(img_mask, img_labels, stats, centroids, 8, CV_32S);

	for (int j = 1; j < numOfLabels; j++)
	{
		int area = stats.at<int>(j, cv::CC_STAT_AREA);
		int left = stats.at<int>(j, cv::CC_STAT_LEFT);
		int top = stats.at<int>(j, cv::CC_STAT_TOP);
		int width = stats.at<int>(j, cv::CC_STAT_WIDTH);
		int height = stats.at<int>(j, cv::CC_STAT_HEIGHT);

		int centerX = centroids.at<double>(j, 0);
		int centerY = centroids.at<double>(j, 1);

		if (area > 700 && area < 2400 /*&& centerX > 100 && centerX < 300 && centerY > 100 && centerY < 300*/)
		{
			for(int k=0; k<circle.size(); k++)
			{
				cv::Vec3i cc = circle[k];
									
				cv::circle(img_color, cv::Point(centerX, centerY), 5, cv::Scalar(255, 0, 0), 1);
				rectangle(img_color, cv::Point(left, top), cv::Point(left + width, top + height), cv::Scalar(0, 0, 255), 1);

				if( (((centerX-cc[0])*(centerX-cc[0]))<100)  && (((centerY-cc[1])*(centerY-cc[1]))<100))
				{
					if(hue_value < 10)
					{
						std::cout << "red" << std::endl;
						printf("%d %d %d %d %d %d", centerX, centerY, cc[0], cc[1], centerX-cc[0], centerY-cc[1]);
						isred=true, isyellow=false, isgreen=false;
					}
					else if(hue_value > 16 && hue_value < 31)
					{
						std::cout << "yellow" << std::endl;
						printf("%d %d %d %d %d %d", centerX, centerY, cc[0], cc[1], centerX-cc[0], centerY-cc[1]);
						isred=false, isyellow=true, isgreen=false;
					}
					else if(hue_value > 71 && hue_value < 120)
					{
						std::cout << "green" << std::endl;
						printf("%d %d %d %d %d %d", centerX, centerY, cc[0], cc[1], centerX-cc[0], centerY-cc[1]);
						isred=false, isyellow=false, isgreen=true;
					}
					else
					{
						isred=false, isyellow=false, isgreen=true;
					}
				}
				//else
				//	printf("none\n");
			}
		}
	}
	return img_result;
}

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;

public:
  ImageConverter()
    : it_(nh_)
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/camera_raw", 1, &ImageConverter::imageCb, this);
    //cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    //cv::destroyWindow(OPENCV_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

	cv::Mat raw_src;
	cv::Mat src;
	cv::Mat colorsrc;
	cv::Mat roi;
	cv::Mat coloroi;
	cv::Mat Med_roi;
	cv::Mat roi_gray;	

	cv::Mat roi_hsv;
	cv::Mat dstImgr;
	cv::Mat dstImgr1;
	cv::Mat dstImgr2;
	cv::Mat dstImgg;
	cv::Mat dstImgy;

	

	colorsrc=cv_ptr->image.clone();

	//roi = src(cv::Rect(100, 0, 440, src.rows/4));
	coloroi = colorsrc(cv::Rect(120, 0, 420, (colorsrc.rows/4)+40));

	cvtColor(coloroi, roi_hsv, cv::COLOR_BGR2HSV);
	cvtColor(coloroi, roi_gray, cv::COLOR_BGR2GRAY);
	check_traffic_light(hue_r_GB, hue_y_GB, hue_g_GB);

	cv::medianBlur(roi_gray, roi_gray, 5);
	//cv::GaussianBlur(roi_gray, roi_gray, cv::Size(3,3), 0.0, 0.0);
	std::vector<cv::Vec3f> circles;
	cv::HoughCircles(roi_gray, circles, cv::HOUGH_GRADIENT, 1.5,
			30,  // change this value to detect circles with different distances to each other
			100, 30, 1, 30 // change the last two parameters
	   // (min_radius & max_radius) to detect larger circles
		);
	for (size_t i = 0; i < circles.size(); i++)
	{
		cv::Vec3i c = circles[i];
		cv::Point center = cv::Point(c[0], c[1]);
		// circle center
		cv::circle(coloroi, center, 1, cv::Scalar(0, 100, 100), 1, cv::LINE_AA);
		// circle outline
		int radius = c[2];
		cv::circle(coloroi, center, radius, cv::Scalar(255, 0, 255), 1, cv::LINE_AA);
	}

	cv::Mat img_result_r, img_result_y, img_result_g;

	img_result_r=morphologyColor(hue_r_GB, roi_hsv, coloroi, lower_red1, lower_red2, lower_red3, upper_red1, upper_red2, upper_red3, circles);
	img_result_y=morphologyColor(hue_y_GB, roi_hsv, coloroi, lower_yellow1, lower_yellow2, lower_yellow3, upper_yellow1, upper_yellow2, upper_yellow3, circles);
	img_result_g=morphologyColor(hue_g_GB, roi_hsv, coloroi, lower_green1, lower_green2, lower_green3, upper_green1, upper_green2, upper_green3, circles);

	/*cv::Scalar lowerr1(0, 30, 30);
	cv::Scalar upperr1(10, 255, 255);

	cv::Scalar lowerr2(150, 30, 30);
	cv::Scalar upperr2(180, 255, 255);

	cv::Scalar lowerg(30, 50, 40);
	cv::Scalar upperg(90, 255, 255);

	cv::Scalar lowery(20, 100, 100);
	cv::Scalar uppery(30, 255, 255);

	int rLastX = -1;
	int rLastY = -1;
	
	cv::cvtColor(coloroi, roi_hsv, CV_BGR2HSV);

	cv::inRange(roi_hsv, lowerr1, upperr1, dstImgr1);
	cv::inRange(roi_hsv, lowerr2, upperr2, dstImgr2);
	dstImgr=dstImgr1 | dstImgr2;
	cv::inRange(roi_hsv, lowerg, upperg, dstImgg);
	cv::inRange(roi_hsv, lowery, uppery, dstImgy);

	cv::erode(dstImgr,dstImgr, getStructuringElement(cv::MORPH_ELLIPSE,cv::Size(5,5)));
	cv::dilate(dstImgr,dstImgr, getStructuringElement(cv::MORPH_ELLIPSE,cv::Size(5,5)));

	cv::dilate(dstImgr,dstImgr, getStructuringElement(cv::MORPH_ELLIPSE,cv::Size(5,5)));
	cv::erode(dstImgr,dstImgr, getStructuringElement(cv::MORPH_ELLIPSE,cv::Size(5,5)));

	cv::Moments rmoments = moments(dstImgr);
	double rM01 = rmoments.m01;
	double rM10 = rmoments.m10;
	double rArea = rmoments.m00;

	if(rArea > 10000)
	{
		int posX=rM10/rArea;
		int posY=rM01/rArea;
		if(rLastX >= 0 && rLastY >= 0 && posX >= 0 && posY >= 0)
		{
			cv::line(dstImgr, cv::Point(posX, posY), cv::Point(rLastX, rLastY), cv::Scalar(0,0,255),2);
		}
		rLastX = posX;
		rLastY = posY;
	}

	cv::imshow("distImage1",dstImgr);
	cv::imshow("distImage2",dstImgg);
	cv::imshow("distImage3",dstImgy);*/
	imshow("img_roi",coloroi);
	imshow("img_result_r", img_result_r);
	imshow("img_result_y", img_result_y);
	imshow("img_result_g", img_result_g);
	cv::waitKey(3);

  }
};

int main(int argc, char** argv)
{
	ros::init(argc, argv, "Traffic");
	ros::NodeHandle s;
	ros::Publisher red_light_pub=s.advertise<std_msgs::Bool>("isred",30);
	ros::Publisher yellow_light_pub=s.advertise<std_msgs::Bool>("isyellow",30);
	ros::Publisher green_light_pub=s.advertise<std_msgs::Bool>("isgreen",30);
	ros::Rate loop_rate(30);
	
	ImageConverter ic;
	while(ros::ok())
	{
		std_msgs::Bool r_light;
		std_msgs::Bool y_light;
		std_msgs::Bool g_light;
		r_light.data=isred;
		y_light.data=isyellow;
		g_light.data=isgreen;
		red_light_pub.publish(r_light);
		yellow_light_pub.publish(y_light);
		green_light_pub.publish(g_light);
		ros::spinOnce();
		loop_rate.sleep();
	}
	ros::spin();
	return 0;
}
