#include "ros/ros.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Bool.h"
#include "std_msgs/Int32.h"
#include "std_msgs/String.h"
#include <iostream>
//#include <time.h>
//#include <queue>

float L_Slope;
float R_Slope;
//bool IsRed;
//bool IsYellow;
//bool IsGreen;
int L_Loc;
int R_Loc;
int C_Loc;
int F_Dist;

int Servo_Value;
bool IsGo;
bool IsLeft;
bool IsRight;
//bool IsLimit;
bool IsFront;
bool IsStopSign;

double Kp = 0.49; //0.55
double Ki = 0.0005;
double Kd = 0.3;

double error;
double error_prev;
double i_error;

int desired_value=320;
int current_value;

double P_control=0, I_control=0, D_control=0; //pid control value
double Time = 0.1;
double PID_control;

int filter_num=0;
int buf_num=0;
double err_arr[7]; //pid error array
double buf_arr[4]; //pid buffer array
bool isFirst=true; //pid array first check value
int change_num=0;
double max_e=-9999;
double min_e=9999;
double sum_err_arr=0;
double filtered_error;
double delayed_filtered_error;

int sig_num=0;
int true_num=0;
int false_num=0;
bool filtered_IsGo=true;

std::string Traffic_sign;
std::string Traffic_light;

bool stop_dist;
bool check_dist;
//float B_Dist;
int X_Rssi;


bool sign_stop;
bool sign_limit;
bool check_limit;
bool check_stop_sign;
int stop_count=0;

bool stop_car; //for another car

//int limit_count=0;


/*
void bool_cb1(const std_msgs::Bool::ConstPtr& msg)
{
	IsRed=msg->data;
	//ROS_INFO("yes_or_no: [%s]", msg->data ? "true" : "false");
}
void bool_cb2(const std_msgs::Bool::ConstPtr& msg)
{
	IsYellow=msg->data;
	//ROS_INFO("yes_or_no: [%s]", msg->data ? "true" : "false");
}
void bool_cb3(const std_msgs::Bool::ConstPtr& msg)
{
	IsGreen=msg->data;
	//ROS_INFO("yes_or_no: [%s]", msg->data ? "true" : "false");
}
*/

void float_cb1(const std_msgs::Float32::ConstPtr& msg)
{
	L_Slope=msg->data;
	//ROS_INFO("value: [%f]", msg->data);
}
void float_cb2(const std_msgs::Float32::ConstPtr& msg)
{
	R_Slope=msg->data;
	//ROS_INFO("value: [%f]", msg->data);
}


void int_cb1(const std_msgs::Int32::ConstPtr& msg)
{
	L_Loc=msg->data;
	//ROS_INFO("value: [%d]", msg->data);
}
void int_cb2(const std_msgs::Int32::ConstPtr& msg)
{
	R_Loc=msg->data;
	//ROS_INFO("value: [%d]", msg->data);
}
void int_cb3(const std_msgs::Int32::ConstPtr& msg)
{
	C_Loc=msg->data;
	//ROS_INFO("value: [%d]", msg->data);
}
void int_cb4(const std_msgs::Int32::ConstPtr& msg)
{
	F_Dist=msg->data;
	//ROS_INFO("value: [%d]", msg->data);
}
void int_cb5(const std_msgs::Int32::ConstPtr& msg)
{
	X_Rssi=msg->data;
	//ROS_INFO("value: [%d]", msg->data);
}

void string_cb1(const std_msgs::String::ConstPtr& msg)
{
	Traffic_sign=msg->data.c_str();
	//ROS_INFO("value: [%d]", msg->data);
}

void string_cb2(const std_msgs::String::ConstPtr& msg)
{
	Traffic_light=msg->data.c_str();
}


int main(int argc, char **argv)
{
	
	ros::init(argc, argv, "Decision");
	ros::NodeHandle n;
	//clock_t start1, end1,end2;
	int i=0;
	bool check_stop=false;
	bool check_sl=false;

	ros::Subscriber left_slope = n.subscribe("l_slope", 30, float_cb1);
	ros::Subscriber right_slope = n.subscribe("r_slope", 30, float_cb2);

	//ros::Subscriber red_right = n.subscribe("isred", 30, bool_cb1);
	//ros::Subscriber yellow_right = n.subscribe("isyellow", 30, bool_cb2);	
	//ros::Subscriber green_right = n.subscribe("isgreen", 30, bool_cb3);	

	ros::Subscriber left_location = n.subscribe("l_location", 30, int_cb1);	
	ros::Subscriber right_location = n.subscribe("r_location", 30, int_cb2);	
	ros::Subscriber center_location = n.subscribe("c_location", 30, int_cb3);	
	ros::Subscriber front_distance = n.subscribe("front_dist", 30, int_cb4);
	ros::Subscriber xbee_rssi = n.subscribe("x_rssi", 30, int_cb5);

	ros::Subscriber traffic_signal = n.subscribe("sign", 30, string_cb1);
	ros::Subscriber traffic_light = n.subscribe("traffic", 30, string_cb2);

	ros::Publisher servo_pub=n.advertise<std_msgs::Int32>("servo",30);
	ros::Publisher tl_pub=n.advertise<std_msgs::Bool>("traffic_light",10);
	ros::Publisher sonar_pub=n.advertise<std_msgs::Bool>("sonar",10);
	ros::Publisher stop_sign_pub=n.advertise<std_msgs::Bool>("stop_sign",10);
	ros::Publisher stop_slave_pub=n.advertise<std_msgs::Bool>("stop_slave",10);

	ros::Rate loop_rate(30);

	while(ros::ok())
	{
		std_msgs::Int32 servo;
		std_msgs::Bool tl;
		std_msgs::Bool stop_sign;
		std_msgs::Bool sonar;
		std_msgs::Bool stop_slave;
		//std_msgs::Bool limit;
		
	//desire->0	
	//PID control	
		//start1=clock();
		current_value=C_Loc;
		error = current_value - desired_value;

		if(filter_num<7) //6~8
		{
			if(isFirst == true)
			{
				err_arr[filter_num]=error;
				filter_num++;
			}
			else
			{
				err_arr[change_num]=error;
				filter_num++;
				change_num++;
			}
		}
		else if(filter_num==7) //6~8
		{
			for(int k=0; k<filter_num; k++)
			{
				if(max_e < err_arr[i])
					max_e=err_arr[i];
				if(min_e > err_arr[i])
					min_e=err_arr[i];
				sum_err_arr+=err_arr[i];
			}
			filtered_error=(sum_err_arr - max_e - min_e)/(filter_num-2);
			sum_err_arr=0;
			max_e = -9999;
			min_e = 9999;

			isFirst=false;
			filter_num--;
			if(change_num==7) //6~8
				change_num=0;

		}
		
		/*buf_arr[buf_num]=filtered_error;
		buf_num++; //save value at array[0], [1], [2]... not use.
		if(buf_num==4) 
		{
			//delayed_filtered_error = buf_arr[buf_num];
			std::printf("%lf %d",buf_arr[buf_num], buf_num);
			buf_num--;
		}*/

		P_control = Kp * filtered_error;//buf_arr[3];

		i_error += filtered_error*Time;

		I_control = Ki * i_error;

		D_control = Kd * (filtered_error-error_prev)/Time;


		error_prev = filtered_error;

		PID_control = P_control + I_control + D_control;


		Servo_Value = (int)PID_control;

		//end1=clock();
		//red or yellow = stop, green or none = go
		/*
		if(IsRed == true || IsYellow == true)
			IsGo = false;
		else if(IsGreen == true)
			IsGo = true;
		else
			IsGo = true;
		*/

		

		/*if(X_Rssi < 40 && X_Rssi > 28 && check_dist == true)
		{
			stop_dist = true;
			std::printf("stop area! %d\n", X_Rssi);
		}
		else if(X_Rssi <=28 )
		{
			stop_dist = false;
			check_dist = false;
			std::printf("just go area! %d\n", X_Rssi);
		}
		else if(X_Rssi >= 28 && stop_dist == false)
		{
			check_dist = true;
			std::printf("just go area escape! %d\n", X_Rssi);
		}*/

		if(X_Rssi < 40)
		{
			stop_dist=true;
		}
		else
		{
			stop_dist=false;
		}

		if(Traffic_light=="stop" && stop_dist==true)
		{
			IsGo = false;
			std::printf("stop to traffic light! %d\n", X_Rssi);
		}
		else if(Traffic_light == "go")
		{
			IsGo = true;
			std::printf("green light! %d\n", X_Rssi);
		}
		else
		{
			IsGo = true;
			std::printf("just go! %d\n", X_Rssi);
		}

		//front sonar sensor
		if(F_Dist <15)
			IsFront = true;
		else
			IsFront = false;

		//traffic sign process
		if(Traffic_sign == "stop sign")
		{
			check_stop_sign=true;
		}
		if(check_stop_sign==true)
		{
			stop_count++;
			if(stop_count < 300)
				sign_stop=true;
			if(stop_count >= 300)
			{
				sign_stop=false;
			}
		}

		if(Traffic_sign != "stop sign" && stop_count >= 400)
		{
			check_stop_sign=false;
			stop_count = 0;
		}

		//stop situation
		if(IsGo == true && sign_stop == false && IsFront == false)
			stop_car=false; //stop
		else 
			stop_car=true; //go


		servo.data=Servo_Value;
		tl.data=IsGo;
		//limit.data=sign_limit;
		sonar.data=IsFront;
		stop_sign.data=sign_stop;
		stop_slave.data=stop_car;

		servo_pub.publish(servo);
		tl_pub.publish(tl);
		sonar_pub.publish(sonar);
		stop_sign_pub.publish(stop_sign);
		stop_slave_pub.publish(stop_slave);
		//end2=clock();

		std::printf("servo_value : %d\n",Servo_Value);
		//std::printf("pid:%f all:%f\n", (float)(end1-start1), (float)(end2-start1) );
		printf("%d", stop_count);
		ros::spinOnce();
		loop_rate.sleep();
	}
	ros::spin();



	return 0;
}
