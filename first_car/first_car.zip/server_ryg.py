#python3

import socket
import sys

import rospy
from std_msgs.msg import String

HOST = '' #all available interfaces
PORT = 8800

#0. define ros publisher
pub = rospy.Publisher('traffic', String, queue_size=30)
rospy.init_node('traffic')

#1. open Socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print ('Socket created')

#2. bind to a address and port
try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print ('Bind Failed. Error code: ' + str(msg[0]) + ' Message: ' + msg[1])
    sys.exit()

print ('Socket bind complete')

#3. Listen for incoming connections
s.listen(10)
print ('Socket now listening')

#4. Accept connection
conn, addr = s.accept()
print ('Connected with ' + addr[0] + ':' + str(addr[1]))
#keep talking with the client
while 1:
   

    
    #5. Read/Send
    data = conn.recv(1024)
    if not data:
        break
    conn.sendall(data)
    print(data.decode())
    pub.publish(String(data.decode()))
    
    
conn.close()
s.close()
