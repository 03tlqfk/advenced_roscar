import socket
import sys

import rospy
from std_msgs.msg import Bool
from std_msgs.msg import Int32

import time

#HOST = '172.30.1.22' #server ip, old car ip at home
HOST = '192.168.43.221'
PORT = 8008

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))


def callback_car_dist(data):
	c_dist = "c_dist:" + str(data.data)
	print(c_dist)
	s.send(c_dist.encode(encoding='utf_8', errors='strict'))
	data=s.recv(1024)
	#time.sleep(0.1)
	

try:
	rospy.init_node('truck_client', anonymous=True)
	rospy.Subscriber("x_rssi_car", Int32, callback_car_dist)
	rospy.spin()

except KeyboardInterrupt:
	print("exit")

finally:
	s.close()




