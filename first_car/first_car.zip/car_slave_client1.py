import socket
import sys

import rospy
from std_msgs.msg import Bool
from std_msgs.msg import Int32

import time

#HOST = '172.30.1.22' #server ip, old car ip at home
HOST = '192.168.43.221'
PORT = 8808

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

	
def callback_slv(data):
	slv = "slv:" + str(data.data)
	print(slv)
	s.send(slv.encode(encoding='utf_8', errors='strict'))
	data=s.recv(1024)
	#time.sleep(0.1)

	
try:
	rospy.init_node('truck_client', anonymous=True)
	rospy.Subscriber("stop_slave", Bool, callback_slv)
	rospy.spin()

except KeyboardInterrupt:
	print("exit")

finally:
	s.close()




